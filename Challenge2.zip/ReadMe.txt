Anleitung f�r die Testumgebung Challenge 2 - SUDOKU

1. Entpacken in einen beliebigen Ordner

2. Das eigene Programm (<Teilnehmer>.exe) in diesen Ordner kopieren

3. Die Challenge2.Bat-Datei ver�ndern, sodass das eigene Programm aufgerufen wird

4. Die Bat-Datei mit Doppelklick ausf�hren - Es wird eine Zeitmessung ausgef�hrt

Meine (Vorab-)L�sung (Kiebart.exe) ist ebenfalls im Ordner - L�sungen aber noch ohne Gew�hr.

Die Datei IN.TXT enth�lt 7000 SUDOKUs (Sind mit SUDOKU-Generator entstanden)

Weitere Testdateien IN(n).TXT

5. Check.Exe ausf�hren (Es wird ermittelt, ob alle SUDOKUs korrekt gel�st wurden) 